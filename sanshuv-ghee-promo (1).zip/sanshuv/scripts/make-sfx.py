# Synthesizes a small, clean SFX kit (16-bit mono WAV, 44.1kHz) into public/sfx/
# Requires: numpy, scipy.  Run: python3 scripts/make-sfx.py
import numpy as np, wave, os
from scipy.signal import butter, sosfilt

SR = 44100
rng = np.random.default_rng(7)
out = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "public", "sfx")
os.makedirs(out, exist_ok=True)


def t(d):
    return np.linspace(0, d, int(SR * d), endpoint=False)


def env(n, a, d):  # fast attack, exponential decay
    e = np.exp(-np.arange(n) / (SR * d))
    k = max(1, int(SR * a))
    e[:k] *= np.linspace(0, 1, k)
    return e


def filt(x, kind, f):
    return sosfilt(butter(2, f, btype=kind, fs=SR, output="sos"), x)


def reverb(x, mix=0.12):
    d = int(SR * 0.045)
    y = x.copy()
    for k, g in ((1, 0.5), (2, 0.3), (3, 0.18)):
        y[d * k:] += x[: -d * k] * g * mix * 4
    return y


def save(name, x, peak):
    x = x / (np.max(np.abs(x)) + 1e-9) * peak
    x[:60] *= np.linspace(0, 1, 60)
    x[-200:] *= np.linspace(1, 0, 200)
    with wave.open(os.path.join(out, name), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes((x * 32767).astype(np.int16).tobytes())


def whoosh(d, lo, hi, peak, name):
    n = int(SR * d)
    x = rng.standard_normal(n)
    y = np.zeros(n)
    seg = 24
    for i in range(seg):
        a, b = i * n // seg, (i + 1) * n // seg
        p = i / (seg - 1)
        f = lo + (hi - lo) * np.sin(p * np.pi / 2) ** 2
        y[a:b] = filt(x[a:b], "bandpass", [f * 0.7, min(f * 1.4, SR / 2 - 100)])
    e = np.sin(np.linspace(0, np.pi, n)) ** 1.6
    save(name, y * e, peak)


def pop(name, peak, f0=520, f1=180):
    tt = t(0.22)
    f = f1 + (f0 - f1) * np.exp(-tt * 38)
    save(name, np.sin(2 * np.pi * np.cumsum(f) / SR) * env(len(tt), 0.002, 0.05), peak)


def click(name, peak):
    n = int(SR * 0.09)
    x = filt(rng.standard_normal(n), "highpass", 3500) * env(n, 0.0005, 0.012)
    tt = t(0.09)
    x += 0.5 * np.sin(2 * np.pi * 1800 * tt) * env(n, 0.0005, 0.008)
    save(name, x, peak)


def chime(name, peak, base=880, d=0.9):
    tt = t(d)
    x = sum(
        a * np.sin(2 * np.pi * base * m * tt) * np.exp(-tt * dec)
        for m, a, dec in ((1, 1, 4.5), (2.01, 0.35, 7), (3.02, 0.15, 10))
    )
    x = filt(x, "lowpass", 6500)
    save(name, reverb(x), peak)


def tick(name, peak):
    tt = t(0.05)
    save(name, np.sin(2 * np.pi * 2400 * tt) * env(len(tt), 0.0005, 0.008), peak)


whoosh(0.45, 500, 3800, 0.30, "whoosh.wav")   # text / scene entry
whoosh(0.30, 900, 5000, 0.24, "swipe.wav")    # scene transition
pop("pop.wav", 0.30)                           # chips / cards
click("click.wav", 0.26)                       # highlight / logo
chime("chime.wav", 0.24, 880, 0.9)             # logo / key claim
chime("chime_low.wav", 0.22, 660, 1.1)         # final guarantee
tick("tick.wav", 0.18)                         # tiny accents
print("ok")
